import sys
import pandas as pd
from fuzzywuzzy import fuzz
from fuzzywuzzy import process

# Function to normalize company names based on a list of canonical names
def normalize_organization_name(organization_name, canonical_names):
    # Remove legal structure variations
    for suffix in legal_structure_suffixes:
        organization_name = organization_name.replace(suffix, '').strip()

    # Fuzzy string matching to find the best match among canonical names
    normalized_name, score = process.extractOne(organization_name, canonical_names)

    # Check if the fuzzy match score is above a threshold (adjust as needed)
    if score >= fuzzy_match_threshold:
        return normalized_name

    # If the score is not high enough, return the original organization name
    return organization_name

# Constants
legal_structure_suffixes = ["INC", "LLC", "LLP", "LTD"]  # Add more if needed
fuzzy_match_threshold = 90  # Adjust as needed

def script_python(input_file, output_file):
    # Read the input CSV file into a DataFrame
    df = pd.read_csv(input_file)

    # Define the canonical company names
    canonical_names = ["MICROSOFT TECHNOLOGY LICENSING", "MICRON TECHNOLOGY", "ELTA SYSTEMS", "DELTA SYSTEMS"]

    # Normalize the organization names in the DataFrame
    df['Normalized organization'] = df['organization'].apply(lambda x: normalize_organization_name(x, canonical_names))

    # Write the DataFrame with normalized names to the output CSV file
    df.to_csv(output_file, index=False)

    print(f"Normalization complete. Output written to {output_file}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Please provide only two arguments. Correct CLI Usage: python normalize_company_names.py <input_file> <output_file>")
        sys.exit(1)
    input_file = sys.argv[1]
    output_file = sys.argv[2]

    script_python(input_file, output_file)
