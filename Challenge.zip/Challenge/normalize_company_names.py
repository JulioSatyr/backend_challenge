import sys
import pandas as pd
from fuzzywuzzy import fuzz
from fuzzywuzzy import process
from collections import Counter

# Dictionary to map variations of suffixes to a common suffix
suffix_mapping = {
    "incorporated": "INC",
    "limited": "LTD",
    "company": "CO",
    "limited": "LLC",
    "limited": "LLP",
        
}

# Function to normalize organization names based on a list of canonical names
def normalize_organization_name(organization_name, canonical_names):
    # Convert the organization name to lowercase for case-insensitivity
    organization_name = organization_name.lower()

    # Replace variations of suffixes with common suffixes
    for variation, common_suffix in suffix_mapping.items():
        organization_name = organization_name.replace(variation, common_suffix)

    # Fuzzy string matching to find the best match among canonical names
    normalized_name, score = process.extractOne(organization_name, [name.lower() for name in canonical_names])

    # Check if the fuzzy match score is above a threshold (adjust as needed)
    if score >= fuzzy_match_threshold:
        return normalized_name

    # If the score is not high enough, return the original organization name
    return organization_name

fuzzy_match_threshold = 90  # Adjust as needed

#Function to order by frequency
def names_by_frequency(names):

    value= Counter(names)
    sorted_values = sorted(value.keys(), key=lambda x: value[x], reverse=True)

    return sorted_values

#Function to make the canonical replace
def canonical_replace(df, ratio):
    normalized_organizations = names_by_frequency(df['normalized_organization'])
    canonical_organizations = {}
    for name in normalized_organizations:
        if name not in canonical_organizations:
            city_name = df[df['normalized_organization']==name]['city'].value_counts().idxmax()
            country_name = df[df['normalized_organization']==name]['country'].value_counts().idxmax()
            for index, row in df.iterrows():
                if ((fuzz.ratio(name, row['normalized_organization']) > ratio) and
                        (country_name==row['country']) and
                        (fuzz.ratio(city_name, row['city']) >ratio)):
                    canonical_organizations[row['normalized_organization']] = name
    return canonical_organizations

#Function to add the organization
def add_canonical_company_names(df,ratio):
    
    df['normalized_organization'] = df['organization'].apply(normalize_organization_name)
    canonical_organizations = canonical_replace(df, ratio)
    df['canonical_organization'] = df['normalized_organization'].map(canonical_organizations)
    df.drop('normalized_organization', axis=1, inplace=True)
    
    return df


def script_python(input_file, output_file):
    # Read the input CSV file into a DataFrame
    df = pd.read_csv(input_file)

    # Normalize the organization names in the DataFrame
    df = add_canonical_company_names(df, fuzzy_match_threshold)  # Use the function you defined

    # Write the DataFrame with normalized names to the output CSV file
    df.to_csv(output_file, index=False)

    print(f"Normalization complete. Output written to {output_file}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Please provide only two arguments. Correct CLI Usage: python normalize_company_names.py <input_file> <output_file>")
        sys.exit(1)
    input_file = sys.argv[1]
    output_file = sys.argv[2]

    script_python(input_file, output_file)
